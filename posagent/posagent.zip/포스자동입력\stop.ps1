﻿# 포스 입력 끄기: 이 PC에서 돌고 있는 포스 입력 창과 실행.cmd를 모두 끔. -Remove 면 자동 시작도 지움
param([switch]$Remove)
$n = 0
Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and "$($_.CommandLine)" -match 'agent\.ps1|실행\.cmd' -and "$($_.CommandLine)" -notmatch 'stop\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $n++ } catch {} }
Write-Host "포스 입력을 껐어요. ($n 개)"
if ($Remove) {
  $lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "베이프렌드 포스입력.lnk"
  if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "자동 시작도 지웠어요." } else { Write-Host "자동 시작은 원래 없어요." }
  Write-Host "이제 이 폴더를 통째로 지우면 끝이에요."
}
