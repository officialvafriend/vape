@echo off
chcp 65001 >nul
cd /d "%~dp0"
:loop
powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0포스자동입력.ps1"
timeout /t 5 /nobreak >nul
goto loop
