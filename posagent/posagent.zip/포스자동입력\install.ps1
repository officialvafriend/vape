﻿# 시작 프로그램에 바로가기 등록 (컴퓨터 켜면 실행.cmd 자동 실행)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "베이프렌드 포스입력.lnk"
$s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$s.TargetPath = Join-Path $here "실행.cmd"; $s.WorkingDirectory = $here; $s.WindowStyle = 7; $s.Save()
if (Test-Path $lnk) { Write-Host "시작 프로그램에 등록했어요. 컴퓨터를 켜면 자동으로 켜져요." } else { Write-Host "등록 못 했어요. 화면을 찍어서 보내 주세요." }