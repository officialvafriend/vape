﻿# 베이프렌드 상담패드 → 포스 자동 입력 (11/16)
# 상담패드 [포스로 보내기] 주문을 슈파베이스(공기계 QR과 같은 주문 표)에서 받아, 포스 화면 오른쪽 아래 알림창에 띄움.
# 직원이 [포스에 넣기]를 누르면 오케이포스 창을 앞으로 가져와 바코드를 스캐너처럼(숫자 + Enter) 대신 입력.
# 승인된 기기만 그 지점 주문을 읽음(처음 켜면 기기 코드가 뜨고, 관리자가 승인). 설정: 같은 폴더 설정.json
param([switch]$Test)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices; using System.Text;
public class W32 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  public static string Title(IntPtr h){ var s=new StringBuilder(512); GetWindowText(h,s,512); return s.ToString(); }
}
"@
$HERE = Split-Path -Parent $MyInvocation.MyCommand.Path
$VER = "1116a"
$SB = "https://bjjlmnkyhedtutogzliq.supabase.co/rest/v1/rpc/"; $KEY = "sb_publishable_i8rfcm_zAnwV75joN58FCw_8tHgFUKr"
$cfgPath = Join-Path $HERE "설정.json"
$cfg = if (Test-Path $cfgPath) { Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { [pscustomobject]@{} }
function CfgGet($k, $d) { if ($cfg.PSObject.Properties[$k] -and "$($cfg.$k)" -ne "") { $cfg.$k } else { $d } }
$BRANCH = CfgGet "지점" "본점"
$TITLE = CfgGet "포스창이름" "OKPOS|오케이포스|포스"     # 오케이포스 창 제목에 들어가는 말(정규식)
$GAP = [int](CfgGet "입력간격ms" 150)
$SEP = CfgGet "구분" "{ENTER}"
$devPath = Join-Path $env:APPDATA "vf-posagent-dev.txt"
if (Test-Path $devPath) { $DEV = (Get-Content $devPath -Raw).Trim() } else { $DEV = -join ((1..18) | ForEach-Object { "{0:x2}" -f (Get-Random -Max 256) }); Set-Content $devPath $DEV }
$SHORT = $DEV.Substring(0, 6).ToUpper()
function Rpc($fn, $body) { Invoke-RestMethod -Uri ($SB + $fn) -Method Post -Headers @{ apikey = $KEY; Authorization = "Bearer $KEY" } -ContentType "application/json; charset=utf-8" -Body ([Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Compress))) -TimeoutSec 8 }
function Won($n) { "{0:N0}원" -f [int]$n }

# ── 알림창 ──
$f = New-Object Windows.Forms.Form
$f.Text = "베이프렌드 포스 입력"; $f.TopMost = $true; $f.FormBorderStyle = "FixedToolWindow"; $f.ShowInTaskbar = $true
$f.Width = 420; $f.Height = 320; $f.StartPosition = "Manual"; $f.BackColor = [Drawing.Color]::White
$wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea; $f.Left = $wa.Right - $f.Width - 12; $f.Top = $wa.Bottom - $f.Height - 12
$font = { param($s, $b) New-Object Drawing.Font("Malgun Gothic", $s, $(if ($b) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular })) }
$lbTop = New-Object Windows.Forms.Label; $lbTop.SetBounds(14, 10, 390, 24); $lbTop.Font = & $font 10 $false; $lbTop.ForeColor = [Drawing.Color]::Gray
$lbMain = New-Object Windows.Forms.Label; $lbMain.SetBounds(14, 36, 390, 120); $lbMain.Font = & $font 12 $true
$btnGo = New-Object Windows.Forms.Button; $btnGo.SetBounds(14, 162, 390, 60); $btnGo.Font = & $font 15 $true; $btnGo.BackColor = [Drawing.Color]::FromArgb(216, 31, 42); $btnGo.ForeColor = [Drawing.Color]::White; $btnGo.FlatStyle = "Flat"
$btnNext = New-Object Windows.Forms.Button; $btnNext.SetBounds(14, 228, 190, 34); $btnNext.Font = & $font 10 $false; $btnNext.Text = "다음 주문 보기"
$btnDone = New-Object Windows.Forms.Button; $btnDone.SetBounds(214, 228, 190, 34); $btnDone.Font = & $font 10 $false; $btnDone.Text = "이 주문 지우기"
$f.Controls.AddRange(@($lbTop, $lbMain, $btnGo, $btnNext, $btnDone))

$script:orders = @(); $script:idx = 0; $script:svcLeft = $null; $script:state = "boot"; $script:busy = $false
function Cur { if ($script:orders.Count) { $script:orders[[Math]::Min($script:idx, $script:orders.Count - 1)] } }
function Draw {
  $lbTop.Text = "$BRANCH 포스 입력  (기기 $SHORT, v$VER)"
  if ($script:state -eq "wait") { $lbMain.Text = "승인을 기다리고 있어요.`n관리자에게 기기 코드 $SHORT 를 알려 주세요."; $btnGo.Visible = $false; $btnNext.Visible = $false; $btnDone.Visible = $false; return }
  if ($script:state -eq "err") { $lbMain.Text = "인터넷 연결을 확인하고 있어요..."; $btnGo.Visible = $false; $btnNext.Visible = $false; $btnDone.Visible = $false; return }
  $o = Cur
  if (-not $o) { $lbMain.Text = "주문 기다리는 중`n상담패드에서 [포스로 보내기]를 누르면 여기에 떠요."; $btnGo.Visible = $false; $btnNext.Visible = $false; $btnDone.Visible = $false; $f.Height = 200; return }
  $f.Height = 320; $f.Top = $wa.Bottom - $f.Height - 12
  $who = ""; if ($o.cust) { $p = "$($o.cust.ph)"; if ($p.Length -ge 4) { $who = " ($($o.cust.nm) ****$($p.Substring($p.Length - 4)))" } }
  $sv = @($o.svc).Count
  if ($script:svcLeft -ne $null -and $script:svcLeft.id -eq $o.id) {
    $lbMain.Text = "$([int]$o.id % 1000)번 결제 상품 $(@($o.codes).Count)개 넣었어요.`n서비스 상품 $sv 개가 남았어요.`n넣은 뒤 포스에서 마지막 $sv 개를 서비스로 바꿔 주세요."
    $btnGo.Text = "서비스 $sv 개 넣기"
  } else {
    $lbMain.Text = "$([int]$o.id % 1000)번 주문$who`n$($o.summary)`n합계 $(Won $o.total)" + $(if ($sv) { "  (서비스 $sv 개 따로)" } else { "" })
    $btnGo.Text = "포스에 넣기 ($(@($o.codes).Count)개)"
  }
  $btnGo.Visible = $true; $btnNext.Visible = $script:orders.Count -gt 1; $btnNext.Text = "다음 주문 ($($script:orders.Count)건 중 $($script:idx + 1))"; $btnDone.Visible = $true
}
function PosWindow { Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -match $TITLE -and $_.Id -ne $PID } | Select-Object -First 1 }
function TypeCodes($codes) {
  $p = PosWindow
  if (-not $p) { [Windows.Forms.MessageBox]::Show("오케이포스 판매 화면을 찾지 못했어요.`n포스 판매 화면을 열어 주세요.", "포스 입력") | Out-Null; return $false }
  [W32]::ShowWindow($p.MainWindowHandle, 9) | Out-Null; [W32]::SetForegroundWindow($p.MainWindowHandle) | Out-Null; Start-Sleep -Milliseconds 400
  $i = 0
  foreach ($c in $codes) {
    if (-not ("$c" -match '^[0-9]{4,20}$')) { continue }   # 숫자 바코드만
    if ([W32]::GetForegroundWindow() -ne $p.MainWindowHandle) { [Windows.Forms.MessageBox]::Show("포스 창이 바뀌어서 멈췄어요. $i 개 넣었어요.", "포스 입력") | Out-Null; return $false }
    [Windows.Forms.SendKeys]::SendWait("$c$SEP"); $i++; $lbMain.Text = "넣는 중 $i / $(@($codes).Count)  (마우스, 키보드는 잠시 그대로)"; $f.Refresh(); Start-Sleep -Milliseconds $GAP
  }
  return $true
}
$btnGo.Add_Click({
  if ($script:busy) { return }; $o = Cur; if (-not $o) { return }; $script:busy = $true
  try {
    if ($script:svcLeft -ne $null -and $script:svcLeft.id -eq $o.id) {
      if (TypeCodes @($o.svc)) { if (-not $Test) { Rpc "qr_done" @{ p_dev = $DEV; p_id = $o.id } | Out-Null }; $script:svcLeft = $null; $script:orders = @($script:orders | Where-Object { $_.id -ne $o.id }); $script:idx = 0
        [Windows.Forms.MessageBox]::Show("다 넣었어요. 마지막 $(@($o.svc).Count)개를 서비스로 바꾸고, 포스 금액이 $(Won $o.total) 인지 확인해 주세요.", "포스 입력") | Out-Null }
    } elseif (TypeCodes @($o.codes)) {
      if (@($o.svc).Count) { $script:svcLeft = $o }
      else { if (-not $Test) { Rpc "qr_done" @{ p_dev = $DEV; p_id = $o.id } | Out-Null }; $script:orders = @($script:orders | Where-Object { $_.id -ne $o.id }); $script:idx = 0
        [Windows.Forms.MessageBox]::Show("다 넣었어요. 포스 금액이 $(Won $o.total) 인지 확인해 주세요.", "포스 입력") | Out-Null }
    }
  } catch { [Windows.Forms.MessageBox]::Show("넣다가 멈췄어요: $($_.Exception.Message)", "포스 입력") | Out-Null }
  $script:busy = $false; $f.Activate(); Draw
})
$btnNext.Add_Click({ if ($script:orders.Count) { $script:idx = ($script:idx + 1) % $script:orders.Count; $script:svcLeft = $null; Draw } })
$btnDone.Add_Click({ $o = Cur; if (-not $o) { return }
  if ([Windows.Forms.MessageBox]::Show("$([int]$o.id % 1000)번 주문을 지울까요? (포스에 안 넣고 끝내기)", "포스 입력", "YesNo") -ne "Yes") { return }
  if (-not $Test) { try { Rpc "qr_done" @{ p_dev = $DEV; p_id = $o.id } | Out-Null } catch {} }
  $script:orders = @($script:orders | Where-Object { $_.id -ne $o.id }); $script:idx = 0; $script:svcLeft = $null; Draw })

# ── 2초마다 새 주문 ──
$t = New-Object Windows.Forms.Timer; $t.Interval = 2000
$t.Add_Tick({
  if ($script:busy) { return }
  if ($Test) { if ($script:state -eq "boot") { $script:state = "ok"; $script:orders = @([pscustomobject]@{ id = 1042; codes = @("2999901866007", "2999901866007", "2999901863006"); svc = @("2999901868001"); summary = "말론S 블랙, 빌런 자두 x2, 메가킥 샤인 외"; total = 147000; cust = [pscustomobject]@{ nm = "클로드98"; ph = "01012341234" } }); Draw
      if ($env:VF_SNAP) { $bm = New-Object Drawing.Bitmap($f.Width, $f.Height); $f.DrawToBitmap($bm, (New-Object Drawing.Rectangle(0, 0, $f.Width, $f.Height))); $bm.Save($env:VF_SNAP); $f.Close() } }; return }
  try {
    $h = Rpc "qr_hello" @{ p_dev = $DEV; p_branch = $BRANCH; p_label = "포스PC $env:COMPUTERNAME" }
    if (-not ("$h".StartsWith("ok:"))) { if ($script:state -ne "wait") { $script:state = "wait"; Draw }; return }
    $list = @(Rpc "qr_pending" @{ p_dev = $DEV })
    $before = ($script:orders | ForEach-Object { $_.id }) -join ","; $script:orders = $list; $after = ($list | ForEach-Object { $_.id }) -join ","
    $was = $script:state; $script:state = "ok"
    if ($before -ne $after -or $was -ne "ok") { if ($script:idx -ge $list.Count) { $script:idx = 0 }; Draw; if ($list.Count -and $before -ne $after) { [System.Media.SystemSounds]::Asterisk.Play(); $f.Activate() } }
  } catch { if ($script:state -ne "err") { $script:state = "err"; Draw } }
})
$t.Start(); Draw
[Windows.Forms.Application]::Run($f)
