@echo off
chcp 65001 >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\베이프렌드 포스입력.lnk'); $s.TargetPath='%~dp0실행.cmd'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"
echo 시작 프로그램에 등록했어요. 이제 컴퓨터를 켜면 자동으로 켜져요.
pause
